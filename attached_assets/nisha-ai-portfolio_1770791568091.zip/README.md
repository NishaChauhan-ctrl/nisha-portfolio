# Nisha Chauhan — AI Portfolio

Minimal React + Vite portfolio showcasing AI projects and product work. Built for GitHub Pages deployment.

## Quick Start
```bash
npm install
npm run dev
```

## Deployment
Push to GitHub, then run:
```bash
npm run deploy
```

Live at: https://nishachauhan-ctrl.github.io
