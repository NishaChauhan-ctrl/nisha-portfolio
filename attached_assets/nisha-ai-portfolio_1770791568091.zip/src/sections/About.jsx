const About = () => (
  <section>
    <h2>About Me</h2>
    <p>I use AI to simplify product workflows. Recently built tools for automated PRDs, feature triage, and support escalation. Master's in Engineering Management.</p>
  </section>
);

export default About;