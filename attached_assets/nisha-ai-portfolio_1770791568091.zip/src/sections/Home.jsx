const Home = () => (
  <section>
    <h1>Nisha Chauhan</h1>
    <p>AI Product Builder | Data to Decisions | Simplifying strategy docs with LLMs</p>
  </section>
);

export default Home;