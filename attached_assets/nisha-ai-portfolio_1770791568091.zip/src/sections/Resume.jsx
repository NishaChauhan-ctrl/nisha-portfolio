const Resume = () => (
  <section>
    <h2>Resume</h2>
    <p><a href='/assets/NishaChauhan_Resume.pdf' target='_blank'>Download Resume (PDF)</a></p>
  </section>
);

export default Resume;